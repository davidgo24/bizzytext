#future reminder for scheduling logic 

def schedule_reminder(appointment_datetime, client_phone):
    print(f"Scheduling reminder for {client_phone} at {appointment_datetime}")